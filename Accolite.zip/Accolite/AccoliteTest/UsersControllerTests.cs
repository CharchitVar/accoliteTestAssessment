﻿using BankingApi.Controllers;
using BankingAPI.Controllers;
using BankingAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Xunit;

public class UsersControllerTests
{
	private readonly UsersController _controller;

	public UsersControllerTests()
	{
		_controller = new UsersController();
	}

	[Fact]
	public void CreateUser_ShouldReturnUser()
	{
		var user = new User { Name = "Test User" };
		var result = _controller.CreateUser(user);

		var okResult = Assert.IsType<OkObjectResult>(result);
		var createdUser = Assert.IsType<User>(okResult.Value);

		Assert.NotNull(createdUser);
		Assert.Equal("Test User", createdUser.Name);
	}

	[Fact]
	public void DeleteUser_ShouldRemoveUser()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_controller.CreateUser(user) as OkObjectResult).Value as User;

		_controller.DeleteUser(createdUser.Id);

		var result = _controller.GetUserById(createdUser.Id);

		Assert.IsType<NotFoundResult>(result);
	}
}
