﻿using BankingAPI.Controllers;
using BankingAPI.Interfaces;
using BankingAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

public class UsersControllerTests
{
	private readonly UsersController _controller;
	private readonly Mock<IUserService> _mockUserService;

	public UsersControllerTests()
	{
		_mockUserService = new Mock<IUserService>();
		_controller = new UsersController(_mockUserService.Object);
	}

	[Fact]
	public void CreateUser_ShouldReturnCreatedUser()
	{
		
		var user = new User { Name = "Test User" };
		_mockUserService.Setup(service => service.CreateUser(user)).Returns(user);

		
		var result = _controller.CreateUser(user);

		
		var okResult = Assert.IsType<OkObjectResult>(result);
		var createdUser = Assert.IsType<User>(okResult.Value);
		Assert.Equal(user.Name, createdUser.Name);
	}

	[Fact]
	public void DeleteUser_ShouldReturnNoContent()
	{
		// Act
		var result = _controller.DeleteUser(1);

		// Assert
		Assert.IsType<NoContentResult>(result);
		_mockUserService.Verify(service => service.DeleteUser(1), Times.Once);
	}

	[Fact]
	public void GetUserById_ShouldReturnUser()
	{
		// Arrange
		var user = new User { Id = 1, Name = "Test User" };
		_mockUserService.Setup(service => service.GetUserById(1)).Returns(user);

		// Act
		var result = _controller.GetUserById(1);

		// Assert
		var okResult = Assert.IsType<OkObjectResult>(result);
		var returnedUser = Assert.IsType<User>(okResult.Value);
		Assert.Equal(user.Id, returnedUser.Id);
		Assert.Equal(user.Name, returnedUser.Name);
	}

	[Fact]
	public void GetUserById_ShouldReturnNotFound()
	{
		// Arrange
		_mockUserService.Setup(service => service.GetUserById(1)).Returns((User)null);

		// Act
		var result = _controller.GetUserById(1);

		// Assert
		Assert.IsType<NotFoundResult>(result);
	}
}
