﻿using BankingApi.Controllers;
using BankingAPI.Controllers;
using BankingAPI.Models;
using BankingAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Xunit;

public class AccountsControllerTests
{
	private readonly AccountsController _controller;
	private readonly UsersController _usersController;
	private readonly IOptions<DepositSettings> _depositSettings;

	public AccountsControllerTests()
	{
		
		_depositSettings = Options.Create(new DepositSettings { MaxDepositAmount = 10000 });

	
		var accountService = new AccountService(_depositSettings);
		var userService = new UserService();

		
		_controller = new AccountsController(accountService);
		_usersController = new UsersController(userService);
	}

	[Fact]
	public void CreateAccount_ShouldReturnAccount()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id };
		var result = _controller.CreateAccount(account);

		var okResult = Assert.IsType<OkObjectResult>(result);
		var createdAccount = Assert.IsType<Account>(okResult.Value);

		Assert.NotNull(createdAccount);
		Assert.Equal(createdUser.Id, createdAccount.UserId);
	}

	[Fact]
	public void DeleteAccount_ShouldRemoveAccount()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id };
		var createdAccount = (_controller.CreateAccount(account) as OkObjectResult).Value as Account;

		_controller.DeleteAccount(createdAccount.Id);

		var result = _controller.GetAccountById(createdAccount.Id);

		Assert.IsType<NotFoundResult>(result);
	}

	[Fact]
	public void Deposit_ShouldIncreaseBalance()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id, Balance = 100 };
		var createdAccount = (_controller.CreateAccount(account) as OkObjectResult).Value as Account;

		_controller.Deposit(createdAccount.Id, 1000);

		var updatedAccount = (_controller.GetAccountById(createdAccount.Id) as OkObjectResult).Value as Account;

		Assert.Equal(1100, updatedAccount.Balance);
	}

	[Fact]
	public void Withdraw_ShouldDecreaseBalance()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id, Balance = 1000 };
		var createdAccount = (_controller.CreateAccount(account) as OkObjectResult).Value as Account;

		_controller.Withdraw(createdAccount.Id, 500);

		var updatedAccount = (_controller.GetAccountById(createdAccount.Id) as OkObjectResult).Value as Account;

		Assert.Equal(500, updatedAccount.Balance);
	}

	[Fact]
	public void Deposit_ShouldNotExceedMaxLimit()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id, Balance = 100 };
		var createdAccount = (_controller.CreateAccount(account) as OkObjectResult).Value as Account;

		var result = _controller.Deposit(createdAccount.Id, 20000);

		Assert.IsType<BadRequestObjectResult>(result);
	}

	[Fact]
	public void Withdraw_ShouldNotExceed90PercentOfBalance()
	{
		var user = new User { Name = "Test User" };
		var createdUser = (_usersController.CreateUser(user) as OkObjectResult).Value as User;
		var account = new Account { UserId = createdUser.Id, Balance = 1000 };
		var createdAccount = (_controller.CreateAccount(account) as OkObjectResult).Value as Account;

		var result = _controller.Withdraw(createdAccount.Id, 950);

		Assert.IsType<BadRequestObjectResult>(result);
	}
}

