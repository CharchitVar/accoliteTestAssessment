﻿using BankingAPI.Data;
using BankingAPI.Interfaces;
using BankingAPI.Models;

namespace BankingAPI.Services
{
	public class UserService : IUserService
	{
		public User CreateUser(User user)
		{
			user.Id = BankingDataStore.Users.Count + 1;
			BankingDataStore.Users.Add(user);
			return user;
		}

		public void DeleteUser(int id)
		{
			var user = BankingDataStore.Users.FirstOrDefault(u => u.Id == id);
			if (user == null)
				return;

			BankingDataStore.Users.Remove(user);
		}

		public User GetUserById(int id)
		{
			return BankingDataStore.Users.FirstOrDefault(u => u.Id == id);
		}
	}
}
