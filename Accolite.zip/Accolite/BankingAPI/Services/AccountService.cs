﻿using BankingAPI.Data;
using BankingAPI.Interfaces;
using BankingAPI.Models;
using Microsoft.Extensions.Options;

namespace BankingAPI.Services
{
	public class AccountService : IAccountService
	{
		private readonly decimal _maxDepositAmount;

		public AccountService(IOptions<DepositSettings> depositSettings)
		{
			_maxDepositAmount = depositSettings.Value.MaxDepositAmount;
		}
		public Account CreateAccount(Account account)
		{
			var user = BankingDataStore.Users.FirstOrDefault(u => u.Id == account.UserId);
			if (user == null)
				return null;

			account.Id = BankingDataStore.Accounts.Count + 1;
			user.Accounts.Add(account);
			BankingDataStore.Accounts.Add(account);
			return account;
		}

		public void DeleteAccount(int id)
		{
			var account = BankingDataStore.Accounts.FirstOrDefault(a => a.Id == id);
			if (account == null)
				return;

			var user = BankingDataStore.Users.FirstOrDefault(u => u.Id == account.UserId);
			if (user != null)
				user.Accounts.Remove(account);

			BankingDataStore.Accounts.Remove(account);
		}

		public Account Deposit(int id, decimal amount)
		{
			if (amount > _maxDepositAmount)
				return null;


			var account = BankingDataStore.Accounts.FirstOrDefault(a => a.Id == id);
			if (account == null)
				return null;

			account.Balance += amount;
			return account;
		}

		public Account Withdraw(int id, decimal amount)
		{
			var account = BankingDataStore.Accounts.FirstOrDefault(a => a.Id == id);
			if (account == null)
				return null;

			if (amount > 0.9m * account.Balance || account.Balance - amount < 100)
				return null;

			account.Balance -= amount;
			return account;
		}

		public Account GetAccountById(int id)
		{
			return BankingDataStore.Accounts.FirstOrDefault(a => a.Id == id);
		}
	}
}
