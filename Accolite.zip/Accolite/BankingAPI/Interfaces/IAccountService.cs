﻿using BankingAPI.Models;

namespace BankingAPI.Interfaces
{
	public interface IAccountService
	{
		Account CreateAccount(Account account);
		void DeleteAccount(int id);
		Account Deposit(int id, decimal amount);
		Account Withdraw(int id, decimal amount);
		Account GetAccountById(int id);
	}
}
