﻿using BankingAPI.Models;

namespace BankingAPI.Interfaces
{
	public interface IUserService
	{
		User CreateUser(User user);
		void DeleteUser(int id);
		User GetUserById(int id);
	}
}
