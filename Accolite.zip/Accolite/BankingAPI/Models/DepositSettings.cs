﻿namespace BankingAPI.Models
{
	public class DepositSettings
	{
		public decimal MaxDepositAmount { get; set; }
	}
}
