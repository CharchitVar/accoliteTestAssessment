﻿using BankingAPI.Models;
using BankingAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BankingAPI.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class UsersController : ControllerBase
	{
		private readonly IUserService _userService;

		public UsersController(IUserService userService)
		{
			_userService = userService;
		}

		[HttpPost]
		public IActionResult CreateUser(User user)
		{
			var createdUser = _userService.CreateUser(user);
			return Ok(createdUser);
		}

		[HttpDelete("{id}")]
		public IActionResult DeleteUser(int id)
		{
			_userService.DeleteUser(id);
			return NoContent();
		}

		[HttpGet("{id}")]
		public IActionResult GetUserById(int id)
		{
			var user = _userService.GetUserById(id);
			if (user == null)
				return NotFound();

			return Ok(user);
		}
	}
}
