﻿using BankingAPI.Interfaces;
using BankingAPI.Models;
using BankingAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingApi.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class AccountsController : ControllerBase
	{
		private readonly IAccountService _accountService;

		public AccountsController(IAccountService accountService)
		{
			_accountService = accountService;
		}

		[HttpPost]
		public IActionResult CreateAccount(Account account)
		{
			var createdAccount = _accountService.CreateAccount(account);
			if (createdAccount == null)
				return NotFound("User not found");

			return Ok(createdAccount);
		}

		[HttpDelete("{id}")]
		public IActionResult DeleteAccount(int id)
		{
			_accountService.DeleteAccount(id);
			return NoContent();
		}

		[HttpPost("{id}/deposit")]
		public IActionResult Deposit(int id, [FromBody] decimal amount)
		{
			var account = _accountService.Deposit(id, amount);
			if (account == null)
				return BadRequest("Deposit amount exceeds $10,000 limit or account not found.");

			return Ok(account);
		}

		[HttpPost("{id}/withdraw")]
		public IActionResult Withdraw(int id, [FromBody] decimal amount)
		{
			var account = _accountService.Withdraw(id, amount);
			if (account == null)
				return BadRequest("Cannot withdraw more than 90% of the balance in a single transaction, or account balance cannot be less than $100.");

			return Ok(account);
		}

		[HttpGet("{id}")]
		public IActionResult GetAccountById(int id)
		{
			var account = _accountService.GetAccountById(id);
			if (account == null)
				return NotFound();

			return Ok(account);
		}
	}
}
